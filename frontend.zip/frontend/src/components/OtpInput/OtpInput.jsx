import React, { useRef, useEffect } from "react";
import "./OtpInput.css";

const OTP_LENGTH = 6;

const OtpInput = ({
                      value = "",
                      onChange = () => {},
                      disabled = false,
                      onResend = null,
                      helperText = "Didn't receive the code? Check your spam or junk folder."
                  }) => {
    const inputRefs = useRef([]);
    const safeValue = String(value || "");
    const otpArray = Array.from({ length: OTP_LENGTH }, (_, i) => safeValue[i] || "");

    useEffect(() => {
        if (disabled) return;
        const firstEmptyIndex = otpArray.findIndex((digit) => !digit);
        const targetIndex = firstEmptyIndex !== -1 ? firstEmptyIndex : 0;
        inputRefs.current[targetIndex]?.focus();
    }, []);

    const handleChange = (e, index) => {
        const rawVal = e.target.value.replace(/\D/g, "");
        const newOtp = [...otpArray];

        if (!rawVal) {
            newOtp[index] = "";
            onChange(newOtp.join(""));
            return;
        }

        if (rawVal.length > 1) {
            const chars = rawVal.split("");
            for (let i = 0; i < chars.length && index + i < OTP_LENGTH; i++) {
                newOtp[index + i] = chars[i];
            }
            onChange(newOtp.join(""));
            const nextFocus = Math.min(index + chars.length, OTP_LENGTH - 1);
            inputRefs.current[nextFocus]?.focus();
            return;
        }

        newOtp[index] = rawVal;
        onChange(newOtp.join(""));

        if (index < OTP_LENGTH - 1) {
            inputRefs.current[index + 1]?.focus();
        }
    };

    const handleKeyDown = (e, index) => {
        if (e.key === "Backspace") {
            e.preventDefault();
            const newOtp = [...otpArray];

            if (newOtp[index]) {
                newOtp[index] = "";
                onChange(newOtp.join(""));
            } else if (index > 0) {
                newOtp[index - 1] = "";
                onChange(newOtp.join(""));
                inputRefs.current[index - 1]?.focus();
            }
        } else if (e.key === "ArrowLeft" && index > 0) {
            e.preventDefault();
            inputRefs.current[index - 1]?.focus();
        } else if (e.key === "ArrowRight" && index < OTP_LENGTH - 1) {
            e.preventDefault();
            inputRefs.current[index + 1]?.focus();
        }
    };

    const handlePaste = (e) => {
        e.preventDefault();
        const pastedData = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, OTP_LENGTH);
        if (!pastedData) return;

        onChange(pastedData);
        const nextIndex = Math.min(pastedData.length, OTP_LENGTH - 1);
        inputRefs.current[nextIndex]?.focus();
    };

    const handleResendClick = () => {
        // Clear input value
        onChange("");
        // Focus back to the first input field
        inputRefs.current[0]?.focus();
        // Trigger resend callback if provided
        if (onResend) {
            onResend();
        }
    };

    return (
        <div className="otp-wrapper">
            <div className="otp-container" onPaste={handlePaste}>
                {otpArray.map((digit, index) => (
                    <input
                        key={index}
                        ref={(el) => (inputRefs.current[index] = el)}
                        type="text"
                        inputMode="numeric"
                        maxLength={1}
                        value={digit}
                        onChange={(e) => handleChange(e, index)}
                        onKeyDown={(e) => handleKeyDown(e, index)}
                        disabled={disabled}
                        className={`otp-slot ${digit ? "otp-slot--filled" : ""}`}
                        aria-label={`Digit ${index + 1} of ${OTP_LENGTH}`}
                        autoComplete="one-time-code"
                    />
                ))}
            </div>

            <p className="otp-helper-text">{helperText}</p>

            {onResend && (
                <button
                    type="button"
                    className="otp-resend-btn"
                    onClick={handleResendClick}
                    disabled={disabled}
                >
                    Resend Code
                </button>
            )}
        </div>
    );
};

export default OtpInput;