import { createContext, useContext, useState, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { loginApi, registerApi, deleteAccountApi, logoutApi } from "../api/auth";
import { registerPushSubscription } from "../api/notifications";
import toast from "react-hot-toast";
const AuthContext = createContext(null);
const readStoredUser = () => {
  try {
    const stored = localStorage.getItem("user");
    const token = localStorage.getItem("token");
    if (!stored || !token) return null;
    return JSON.parse(stored);
  } catch {
    return null;
  }
};
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(readStoredUser);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const onLoginRef  = useRef(null);
  const onLogoutRef = useRef(null);
  const registerOnLogin  = useCallback((fn) => { onLoginRef.current  = fn; }, []);
  const registerOnLogout = useCallback((fn) => { onLogoutRef.current = fn; }, []);
  const persistSession = (token, username, email) => {
    localStorage.setItem("token", token);
    localStorage.setItem("user", JSON.stringify({ username, email }));
    setUser({ username, email });
  };
  const clearSession = useCallback(() => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setUser(null);
  }, []);
  const login = async (credentials) => {
    setIsLoading(true);
    try {
      const res = await loginApi(credentials);
      const { token, username, email } = res.data;
      persistSession(token, username, email);
      if (onLoginRef.current) await onLoginRef.current();
      registerPushSubscription().catch(() => {});
      toast.success("Signed in successfully");
      navigate("/dashboard");
    } catch (err) {
      const msg = err.response?.data?.message || err.response?.data?.errors?.username || "Login failed";
      toast.error(msg);
    } finally {
      setIsLoading(false);
    }
  };
  const register = async (data) => {
    setIsLoading(true);
    try {
      const res = await registerApi(data);
      toast.success("Verification code sent to your email!");
      return res.data;
    } catch (err) {
      const errors = err.response?.data?.errors;
      if (errors) {
        toast.error(Object.values(errors)[0]);
      } else {
        toast.error(err.response?.data?.message || "Registration failed");
      }
      throw err;
    } finally {
      setIsLoading(false);
    }
  };
  const logout = useCallback(() => {
    // best effort, revoke the token server side too, session clears either way
    logoutApi().catch(() => {});
    clearSession();
    if (onLogoutRef.current) onLogoutRef.current();
    toast.success("Signed out");
    navigate("/", { replace: true, state: null });
  }, [clearSession, navigate]);
  // deletes account on backend then clears session same as logout
  const deleteAccount = async (password) => {
    setIsLoading(true);
    try {
      await deleteAccountApi(password);
      clearSession();
      if (onLogoutRef.current) onLogoutRef.current();
      toast.success("Account deleted");
      navigate("/", { replace: true, state: null });
    } catch (err) {
      const data = err.response?.data;
      const msg = typeof data === "string" ? data : (data?.message || "Could not delete account");
      toast.error(msg);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };
  return (
      <AuthContext.Provider value={{
        user,
        isLoading,
        login,
        register,
        logout,
        deleteAccount,
        registerOnLogin,
        registerOnLogout,
      }}>
        {children}
      </AuthContext.Provider>
  );
};
export const useAuth = () => useContext(AuthContext);